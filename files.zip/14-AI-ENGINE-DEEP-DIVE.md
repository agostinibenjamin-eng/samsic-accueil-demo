# 14 — Moteur IA — Spécification technique approfondie

> Comment le moteur "apprend", quelle stack, comment monitorer, est-ce faisable avec Antigravity/Claude Code ?

## Ce que nous faisons vs ce que nous NE faisons PAS

| ✅ Ce qu'on fait | ❌ Ce qu'on ne fait PAS |
|-----------------|----------------------|
| Scoring algorithmique pondéré (8 critères, déterministe) | Deep learning / réseaux de neurones |
| Apprentissage par feedback (ajustement de poids) | Entraînement sur GPU |
| Moteur de règles métier enrichi | Appels à GPT/Claude pour chaque décision |
| Analyse prédictive par patterns (V3) | Boîte noire inexplicable |

**Pourquoi** : 44 employés = pas assez de données pour du ML. Le scoring pondéré est 100% explicable, instantané (<200ms), fonctionne dès jour 1 sans données d'entraînement, et maintenable par un développeur standard.

## Stack technique du moteur IA

| Composant | Choix | Raison |
|-----------|-------|--------|
| Langage | TypeScript | Même stack que le reste, pas besoin de Python |
| Runtime | NestJS module dédié | Injection de dépendances, testable |
| BDD | PostgreSQL (Prisma) | Requêtes complexes, ACID |
| Calcul | CPU natif | Arithmétique pondérée, pas besoin de GPU |
| Scheduler | @nestjs/schedule | Rapport hebdo, recalcul polyvalence |
| Cache | In-memory (V1), Redis (V2) | Scores polyvalence, poids par client |
| Tests | Jest | Chaque critère testé unitairement |

## 3 mécanismes d'apprentissage

### 1. Ajustement des pondérations par client
Quand un opérateur refuse suggestion #1 et choisit un autre candidat, le système compare les scores détaillés et ajuste les poids pour ce client (±2% par feedback, learning rate décroissant, plafonné ±10%). Stocké dans `ClientWeightOverride`. Confiance maximale après 20 observations.

### 2. Affinités employé ↔ client
Score -10 à +10 par couple employé/client. Monte : choisi manuellement (+2), accepté par IA (+1), bon feedback (+1.5). Baisse : refusé (-1), mauvais feedback (-3), bloqué (-10). Appliqué comme bonus/malus ±8 points max sur le score total. Stocké dans `EmployeeClientAffinity`.

### 3. Règles métier accumulées
Table `BusinessRule` : conditions JSON + action JSON. Types : PREFERENCE (soft), CONSTRAINT (hard), BONUS, MALUS. Exemples : "Ne jamais envoyer un junior chez PwC le lundi", "Sophie +5 chez Bank of China".

## Monitoring du moteur

### Métriques performance
| Métrique | Seuil alerte |
|----------|-------------|
| Temps scoring p95 | >500ms |
| Candidats éligibles par recherche | <3 |
| Cascades déclenchées | >20% = pool sous-dimensionné |

### Métriques apprentissage
| Métrique | Seuil alerte |
|----------|-------------|
| Taux acceptation #1 | <60% après 3 mois |
| Taux acceptation top 3 | <85% |
| Overrides manuels | >30% = problème |
| Oscillation poids client | >0.05/semaine = conflit préférences |

### Alertes santé moteur
- **Drift** : taux acceptation baisse >10% sur 2 semaines → revoir poids
- **Pool critique** : <3 candidats éligibles → recruter ou former
- **Oscillation** : préférences contradictoires entre opérateurs → clarifier

## Faisabilité et effort

### V1 (8 semaines) — ~15-16 jours de dev

| Composant | Jours |
|-----------|-------|
| Scoring 8 critères | 3-4 |
| Critères d'élimination | 1 |
| Cascade solver (profondeur 2) | 2 |
| Explication score | 1 |
| Learning — ajustement poids | 2 |
| Learning — affinités | 1 |
| Risk report hebdo | 2 |
| Indice fragilité + polyvalence | 1.5 |
| Monitoring (logs) | 1 |
| Tests unitaires complets | 2 |

### V2 (3-6 mois) : Dashboard monitoring IA, business rules UI, Redis cache, notifications prédictives
### V3 (9-12 mois) : Prédiction absences (patterns), pré-positionnement auto, auto-tuning A/B

## Développement avec Antigravity/Claude Code

100% faisable car c'est du TypeScript pur. Chaque fonction est spécifiée dans ce markdown. Skills à utiliser : `@typescript-expert`, `@test-driven-development`, `@testing-patterns`, `@debugging-strategies`, `@architecture`.

Prompt type : "Implémente `scoring.service.ts` selon la spec dans `docs/architecture/04-AI-ENGINE.md`. Utilise Prisma pour les requêtes, le modèle de `docs/data-model/03-DATA-MODEL.md`. Inclus les tests unitaires."

## Ce qui rend ce moteur "intelligent"

1. **Modélisation métier profonde** : les 8 critères reflètent le raisonnement de Mandy
2. **Boucle de feedback continue** : après 100 décisions, le moteur connaît les préférences implicites
3. **Transparence totale** : l'opérateur voit POURQUOI → confiance
4. **Anticipation** : rapport de risque dimanche soir → proactivité vs réaction
5. **Scalabilité du savoir** : quand un nouvel opérateur arrive, la connaissance est dans le système
